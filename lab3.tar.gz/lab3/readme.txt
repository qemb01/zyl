编译：gcc menu.c linktable.c testmenu.c testcase.c -o Test
运行：./Test
