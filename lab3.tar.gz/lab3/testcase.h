/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  testcase.h                                                          */
/*  PRINCIPAL AUTHOR      :  Zhuyiliang                                                           */
/*  SUBSYSTEM NAME        :  testcase                                                                 */
/*  MODULE NAME           :  testcase                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a testcase program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhuyiliang   , 2014/09/28
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include "menu.h"


/***test translating tDataNode[] into LinkTable******************************************************/
void testChangeToLinkTable(tLinkTable *Node,tDataNode menu[]);

/***test getting cmd list****************************************************************************/
void testShowAll(tLinkTable *Node,tDataNode menu[]);

/***get desc by cmd**********************************************************************************/
void testGetByCmd(tLinkTable *Node,tDataNode menu[],char *cmd);

/***get Length of the tDataNode variable*************************************************************/
void testGetNodeLength(tLinkTable *Node,tDataNode menu[]);

