/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  testmenu.c                                                          */
/*  PRINCIPAL AUTHOR      :  Zhuyiliang                                                           */
/*  SUBSYSTEM NAME        :  testmenu                                                                 */
/*  MODULE NAME           :  testmenu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a testcase program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhuyiliang   , 2014/09/28
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "testcase.h"
#define CMD_MAX_LEN 128

tLinkTable *Node;

int getHelp()
{
    showAllCmd(Node);
    return 1;
}


tDataNode menu[] =
{
    {NULL,"help", "this is help!","help you find cmd", getHelp},
    {NULL,"version", "menu's version.", "zhuyiliang_v1", NULL}  
};



void main()
{
    testGetNodeLength(Node,menu);
    testChangeToLinkTable(Node,menu);
    testShowAll(Node,menu);
    Node=changeToLinkTable(menu);
    char cmd[CMD_MAX_LEN]="version";
    testGetByCmd(Node,menu,cmd);
}
