/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  testcase.c                                                          */
/*  PRINCIPAL AUTHOR      :  Zhuyiliang                                                           */
/*  SUBSYSTEM NAME        :  testcase                                                                 */
/*  MODULE NAME           :  testcase                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/28                                                           */
/*  DESCRIPTION           :  This is a testcase program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhuyiliang   , 2014/09/28
 *
 */
#include "testcase.h"

/***test translating tDataNode[] into LinkTable******************************************************/
void testChangeToLinkTable(tLinkTable *Node,tDataNode* menu)
{
    printf("this is testcase of changeToLinkTable:\n");
    Node=changeToLinkTable(menu);
    int len=0;
    len=getNodeLength(Node);
    if(len!=0)
    {
        printf("changeToLinkTable have good work!\n\n");
    }
    else
    {
        printf("changeToLinkTable doesn't work!\n\n");
    }  
}

/***test getting cmd list****************************************************************************/
void testShowAll(tLinkTable *Node,tDataNode* menu)
{
    printf("this is testcase of showAllCmd:\n");
    Node=changeToLinkTable(menu);
    showAllCmd(Node);
    printf("showAllCmd have good work!\n\n");
}


/***test get desc by cmd**********************************************************************************/
void testGetByCmd(tLinkTable *Node,tDataNode* menu,char * cmd)
{
    printf("this is testcase of getByCmd:\n");
    printf("Your test cmd is : %s\n",cmd);
    tDataNode* tNode;
    Node=changeToLinkTable(menu);
    tNode=getByCmd(Node,cmd);
    if(tNode!=NULL)
    {
        printf("%s - %s\n", tNode->cmd, tNode->desc);
        if(tNode->handler != NULL)
        {
            tNode->handler();
        } 
        printf("getByCmd have good work!\n\n");
    }
    else
    {
        printf("getByCmd doesn't work!\n\n");
    }
    
}

/***test get Length of the tDataNode variable*************************************************************/
void testGetNodeLength(tLinkTable *Node,tDataNode* menu)
{
    printf("this is testcase of getNodeLength:\n");
    Node=changeToLinkTable(menu); 
    int len=0;
    len=getNodeLength(Node);
    if(len!=0)
    {
	printf("the length is : %d\n",len);        
        printf("getNodeLength have good work!\n\n");
    }
    else
    {
        printf("getNodeLength doesn't work!\n\n");
    }
}

